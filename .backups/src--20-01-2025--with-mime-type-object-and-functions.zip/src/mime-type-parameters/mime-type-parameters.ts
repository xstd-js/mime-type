import { getAllMIMETypeParametersFromMIMETypeParametersList } from './functions.private/access/get-all-mime-type-parameters-from-mime-type-parameters-list.js';
import { getMIMETypeParameterFromMIMETypeParametersList } from './functions.private/access/get-mime-type-parameter-from-mime-type-parameters-list.js';
import { hasMIMETypeParameterInMIMETypeParametersList } from './functions.private/access/has-mime-type-parameter-in-mime-type-parameters-list.js';
import { createMIMETypeParametersListFrom } from './functions.private/from/create-mime-type-parameters-list-from.js';
import { appendMIMETypeParameterToMIMETypeParametersList } from './functions.private/mutate/append-mime-type-parameter-to-mime-type-parameters-list.js';
import { deleteMIMETypeParameterFromMIMETypeParametersList } from './functions.private/mutate/delete-mime-type-parameter-from-mime-type-parameters-list.js';
import { setMIMETypeParameterInMIMETypeParametersList } from './functions.private/mutate/set-mime-type-parameter-in-mime-type-parameters-list.js';
import { sortMIMETypeParametersList } from './functions.private/mutate/sort-mime-type-parameters-list.js';
import { serializeMIMETypeParametersList } from './functions.private/to/serialize-mime-type-parameters-list.js';
import { type MIMETypeParameterTuple } from './types/mime-type-parameter-tuple.js';
import { type MIMETypeParametersInit } from './types/mime-type-parameters-init.js';

/* TYPES */

export interface MIMETypeParametersToStringOptions {
  readonly includeLeadingSeparator?: boolean; // (default: true)
}

/* CLASS */

/**
 * Represents a list of parameters of a MIME type.
 */
export class MIMETypeParameters {
  /**
   * Returns `true` if `input` can be parsed into valid MIME type parameters.
   */
  static canParse(input: string): boolean {
    return this.parse(input) !== null;
  }

  /**
   * Returns a `MIMETypeParameters` if `input` can be parsed into valid parameters, else it returns `null`.
   */
  static parse(input: string): MIMETypeParameters | null {
    try {
      return new MIMETypeParameters(input);
    } catch {
      return null;
    }
  }

  readonly #parameters: MIMETypeParameterTuple[];

  /**
   * Constructs a new MIMETypeParameters from an input string, an Iterable of key/value, or an object of key/value.
   *
   * Throws if the `input` is invalid.
   *
   * > If the `input` is a string, the leading separator `;` bay be omitted.
   *
   * @example
   * ```ts
   * const parameters = new MIMETypeParameters('; encoding=utf-8');
   * ```
   */
  constructor(init?: MIMETypeParametersInit) {
    this.#parameters = [];

    if (init !== undefined) {
      createMIMETypeParametersListFrom(init, this.#parameters);
    }
  }

  /**
   * Returns the number of parameters.
   */
  get size(): number {
    return this.#parameters.length;
  }

  /**
   * Appends a specified key/value pair as a new parameter.
   */
  append(key: string, value: string): void {
    return appendMIMETypeParameterToMIMETypeParametersList(this.#parameters, key, value);
  }

  /**
   * Deletes specified parameters and their associated value(s) from the list of all parameters.
   */
  delete(key: string, value?: string): void {
    return deleteMIMETypeParameterFromMIMETypeParametersList(this.#parameters, key, value);
  }

  /**
   * Returns the first value associated to the given parameter.
   */
  get(key: string): string | null {
    return getMIMETypeParameterFromMIMETypeParametersList(this.#parameters, key);
  }

  /**
   * Returns all the values associated with a given parameter as an array.
   */
  getAll(key: string): string[] {
    return getAllMIMETypeParametersFromMIMETypeParametersList(this.#parameters, key);
  }

  /**
   * Returns a boolean value that indicates whether the specified parameter is in the parameters.
   */
  has(key: string, value?: string): boolean {
    return hasMIMETypeParameterInMIMETypeParametersList(this.#parameters, key, value);
  }

  /**
   * Sets the value associated with a given parameter to the given value.
   * If there were several matching values, this method deletes the others.
   * If the parameter doesn't exist, this method creates it.
   */
  set(key: string, value: string): void {
    return setMIMETypeParameterInMIMETypeParametersList(this.#parameters, key, value);
  }

  /**
   * Removes all the parameters.
   */
  clear(): void {
    this.#parameters.length = 0;
  }

  /**
   * Sorts all key/value pairs contained in this object in place.
   * The sort order is according to unicode code points of the keys.
   * This method uses a stable sorting algorithm (i.e. the relative order between key/value pairs with equal keys will be preserved).
   */
  sort(): void {
    sortMIMETypeParametersList(this.#parameters);
  }

  /**
   * Returns an `Iterator` allowing iteration through all keys contained in this object.
   * The keys are strings.
   */
  *keys(): Generator<string> {
    for (let i: number = 0; i < this.#parameters.length; i++) {
      yield this.#parameters[i][0];
    }
  }

  /**
   * Returns an `Iterator` allowing iteration through all values contained in this object.
   */
  *values(): Generator<string> {
    for (let i: number = 0; i < this.#parameters.length; i++) {
      yield this.#parameters[i][1];
    }
  }

  /**
   * Returns an `Iterator` allowing iteration through all key/value pairs contained in this object.
   * The iterator returns key/value pairs in the same order as they appear in the parameters string.
   * The key and value of each pair are strings.
   */
  *entries(): Generator<MIMETypeParameterTuple> {
    for (let i: number = 0; i < this.#parameters.length; i++) {
      yield this.#parameters[i];
    }
  }

  /**
   * Alias of `.entries()`.
   *
   * @see MIMETypeParameters.entries
   */
  [Symbol.iterator](): IterableIterator<MIMETypeParameterTuple> {
    return this.entries();
  }

  /**
   * Allows iteration through all values contained in this object via a callback function.
   */
  forEach(callback: (value: string, key: string, parameters: MIMETypeParameters) => void): void {
    for (let i: number = 0; i < this.#parameters.length; i++) {
      callback(this.#parameters[i][0], this.#parameters[i][1], this);
    }
  }

  /**
   * Returns a MIME type parameters string suitable for use in a MIME type.
   */
  toString(options?: MIMETypeParametersToStringOptions): string {
    return serializeMIMETypeParametersList(this.#parameters, options);
  }
}
