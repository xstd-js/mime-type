import { MIMETypeParameterTuple } from './mime-type-parameter-tuple.js';

export type MIMETypeParametersList = MIMETypeParameterTuple[];

export type ReadonlyMIMETypeParametersList = readonly MIMETypeParameterTuple[];
