export type MIMETypeParameterTuple = readonly [key: string, value: string];
