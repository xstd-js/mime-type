import { type MIMETypeParameterTuple } from './mime-type-parameter-tuple.js';

export type MIMETypeParametersInit =
  | Iterable<MIMETypeParameterTuple>
  | Record<string, string>
  | string;
