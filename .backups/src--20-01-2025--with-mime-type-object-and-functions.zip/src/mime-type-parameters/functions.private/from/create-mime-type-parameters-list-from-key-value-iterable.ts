import { type MIMETypeParameterTuple } from '../../types/mime-type-parameter-tuple.js';
import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { appendMIMETypeParameterToMIMETypeParametersList } from '../mutate/append-mime-type-parameter-to-mime-type-parameters-list.js';

export function createMIMETypeParametersListFromKeyValueIterable(
  input: Iterable<MIMETypeParameterTuple>,
  output: MIMETypeParametersList = [],
): MIMETypeParametersList {
  const iterator: Iterator<MIMETypeParameterTuple> = input[Symbol.iterator]();
  let result: IteratorResult<MIMETypeParameterTuple>;
  while (!(result = iterator.next()).done) {
    appendMIMETypeParameterToMIMETypeParametersList(output, result.value[0], result.value[1]);
  }
  return output;
}
