import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { MIME_TYPE_PARAMETER_TOKEN_PATTERN } from '../constants.js';
import { appendMIMETypeParameterToMIMETypeParametersList } from '../mutate/append-mime-type-parameter-to-mime-type-parameters-list.js';

/* CONSTANT */

const MIMETypeParameterRegExp = new RegExp(
  `;\\s*(${MIME_TYPE_PARAMETER_TOKEN_PATTERN}+)=(?:"((?:[^"\\\\]|\\\\"|\\\\[^"])+?)"|(${MIME_TYPE_PARAMETER_TOKEN_PATTERN}+))\\s*`,
  'g',
);

/* FUNCTION */

/**
 * Parses an input string as a list of MIME type parameters.
 */
export function parseMIMETypeParametersList(
  input: string,
  output: MIMETypeParametersList = [],
): MIMETypeParametersList {
  if (input !== '') {
    if (!input.startsWith(';')) {
      input = ';' + input;
    }

    let match: RegExpExecArray | null;
    MIMETypeParameterRegExp.lastIndex = 0;
    let index: number = 0;
    while ((match = MIMETypeParameterRegExp.exec(input)) !== null) {
      index = match.index + match[0].length;

      // TODO improve by checking HERE if index is correct relative to the previous one

      appendMIMETypeParameterToMIMETypeParametersList(
        output,
        match[1],
        match[3] === undefined ? /* mode quoted-string */ match[2].replaceAll('\\', '') : match[3],
      );
    }

    if (index !== input.length) {
      throw new Error(
        `Parameters ${JSON.stringify(`${input.slice(index, index + 30)}${index + 30 < input.length ? '...' : ''}`)} are not valid.`,
      );
    }
  }

  return output;
}
