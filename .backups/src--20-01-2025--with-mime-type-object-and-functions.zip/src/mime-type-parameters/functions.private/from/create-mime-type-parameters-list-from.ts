import { type MIMETypeParametersInit } from '../../types/mime-type-parameters-init.js';
import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { createMIMETypeParametersListFromKeyValueIterable } from './create-mime-type-parameters-list-from-key-value-iterable.js';
import { createMIMETypeParametersListFromKeyValueObject } from './create-mime-type-parameters-list-from-key-value-object.js';
import { parseMIMETypeParametersList } from './parse-mime-type-parameters-list.js';

export function createMIMETypeParametersListFrom(
  input: MIMETypeParametersInit,
  output: MIMETypeParametersList = [],
): MIMETypeParametersList {
  if (typeof input === 'string') {
    return parseMIMETypeParametersList(input, output);
  } else if (typeof input === 'object' && input !== null) {
    if (Symbol.iterator in input) {
      return createMIMETypeParametersListFromKeyValueIterable(input, output);
    } else {
      return createMIMETypeParametersListFromKeyValueObject(input, output);
    }
  } else {
    throw new TypeError('Invalid input type.');
  }
}
