import { type MIMETypeParameterTuple } from '../../types/mime-type-parameter-tuple.js';
import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { appendMIMETypeParameterToMIMETypeParametersList } from '../mutate/append-mime-type-parameter-to-mime-type-parameters-list.js';

export function createMIMETypeParametersListFromKeyValueObject(
  input: Record<string, string>,
  output: MIMETypeParametersList = [],
): MIMETypeParametersList {
  Object.entries(input).forEach(([key, value]: MIMETypeParameterTuple): void => {
    appendMIMETypeParameterToMIMETypeParametersList(output, key, value);
  });
  return output;
}
