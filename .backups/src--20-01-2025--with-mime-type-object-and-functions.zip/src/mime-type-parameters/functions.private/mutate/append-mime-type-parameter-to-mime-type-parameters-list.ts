import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { normalizeMIMETypeParameterKey } from '../verify/verify-mime-type-parameter-key.js';
import { normalizeMIMETypeParameterValue } from '../verify/verify-mime-type-parameter-value.js';

export function appendMIMETypeParameterToMIMETypeParametersListUnsafe(
  parameters: MIMETypeParametersList,
  key: string,
  value: string,
): void {
  parameters.push(Object.freeze([key, value]));
}

export function appendMIMETypeParameterToMIMETypeParametersList(
  parameters: MIMETypeParametersList,
  key: string,
  value: string,
): void {
  appendMIMETypeParameterToMIMETypeParametersListUnsafe(
    parameters,
    normalizeMIMETypeParameterKey(key),
    normalizeMIMETypeParameterValue(value),
  );
}
