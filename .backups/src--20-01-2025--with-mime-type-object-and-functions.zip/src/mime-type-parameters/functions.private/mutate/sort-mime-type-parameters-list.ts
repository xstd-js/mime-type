import { type MIMETypeParameterTuple } from '../../types/mime-type-parameter-tuple.js';
import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';

export function sortMIMETypeParametersList(parameters: MIMETypeParametersList): void {
  parameters.sort(([keyA]: MIMETypeParameterTuple, [keyB]: MIMETypeParameterTuple): number => {
    if (keyA < keyB) {
      return -1;
    } else if (keyA > keyB) {
      return 1;
    } else {
      return 0;
    }
  });
}
