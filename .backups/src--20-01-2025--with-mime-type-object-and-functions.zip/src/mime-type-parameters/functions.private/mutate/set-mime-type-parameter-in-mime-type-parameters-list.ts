import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { normalizeMIMETypeParameterKey } from '../verify/verify-mime-type-parameter-key.js';
import { normalizeMIMETypeParameterValue } from '../verify/verify-mime-type-parameter-value.js';
import { appendMIMETypeParameterToMIMETypeParametersListUnsafe } from './append-mime-type-parameter-to-mime-type-parameters-list.js';
import { deleteMIMETypeParameterFromMIMETypeParametersListUnsafe } from './delete-mime-type-parameter-from-mime-type-parameters-list.js';

export function setMIMETypeParameterInMIMETypeParametersListUnsafe(
  parameters: MIMETypeParametersList,
  key: string,
  value: string,
): void {
  deleteMIMETypeParameterFromMIMETypeParametersListUnsafe(parameters, key);
  appendMIMETypeParameterToMIMETypeParametersListUnsafe(parameters, key, value);
}

export function setMIMETypeParameterInMIMETypeParametersList(
  parameters: MIMETypeParametersList,
  key: string,
  value: string,
): void {
  setMIMETypeParameterInMIMETypeParametersListUnsafe(
    parameters,
    normalizeMIMETypeParameterKey(key),
    normalizeMIMETypeParameterValue(value),
  );
}
