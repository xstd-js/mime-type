import { type MIMETypeParameterTuple } from '../../types/mime-type-parameter-tuple.js';
import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { normalizeMIMETypeParameterKey } from '../verify/verify-mime-type-parameter-key.js';
import { normalizeMIMETypeParameterValue } from '../verify/verify-mime-type-parameter-value.js';

export function deleteMIMETypeParameterFromMIMETypeParametersListUnsafe(
  parameters: MIMETypeParametersList,
  key: string,
  value?: string,
): void {
  for (let i: number = 0; i < parameters.length; i++) {
    const [_key, _value]: MIMETypeParameterTuple = parameters[i];

    if (_key === key && (value === undefined || _value == value)) {
      parameters.splice(i, 1);
      i--;
    }
  }
}

export function deleteMIMETypeParameterFromMIMETypeParametersList(
  parameters: MIMETypeParametersList,
  key: string,
  value?: string,
): void {
  deleteMIMETypeParameterFromMIMETypeParametersListUnsafe(
    parameters,
    normalizeMIMETypeParameterKey(key),
    normalizeMIMETypeParameterValue(value),
  );
}
