export const MIME_TYPE_PARAMETER_TOKEN_INNER_PATTERN =
  "0-9a-zA-Z\\!\\#\\$\\%\\&'\\*\\+\\-\\.\\^_\\`\\|\\~";
export const MIME_TYPE_PARAMETER_TOKEN_PATTERN = `[${MIME_TYPE_PARAMETER_TOKEN_INNER_PATTERN}]`;
