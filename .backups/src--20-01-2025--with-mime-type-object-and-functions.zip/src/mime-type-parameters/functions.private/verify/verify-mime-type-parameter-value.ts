const MIMETypeParameterValueRegExp = new RegExp('^[\\u0009\\u0020-\\u007e]*$');

export function verifyMIMETypeParameterValue(value: string): void {
  if (!MIMETypeParameterValueRegExp.test(value)) {
    throw new Error('Invalid parameter key');
  }
}

export function normalizeMIMETypeParameterValue<GValue extends string | undefined>(
  value: GValue,
): GValue {
  if (value !== undefined) {
    verifyMIMETypeParameterValue(value);
  }
  return value;
}
