import { MIME_TYPE_PARAMETER_TOKEN_PATTERN } from '../constants.js';

const MIMETypeParameterKeyRegExp = new RegExp(`^${MIME_TYPE_PARAMETER_TOKEN_PATTERN}+$`);

export function verifyMIMETypeParameterKey(key: string): void {
  if (!MIMETypeParameterKeyRegExp.test(key)) {
    throw new Error('Invalid parameter key');
  }
}

export function normalizeMIMETypeParameterKey(key: string): string {
  verifyMIMETypeParameterKey(key);
  return key.toLowerCase();
}
