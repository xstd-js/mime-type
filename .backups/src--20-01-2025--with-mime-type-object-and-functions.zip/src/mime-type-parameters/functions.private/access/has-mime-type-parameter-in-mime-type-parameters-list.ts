import { type MIMETypeParameterTuple } from '../../types/mime-type-parameter-tuple.js';
import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { normalizeMIMETypeParameterKey } from '../verify/verify-mime-type-parameter-key.js';
import { normalizeMIMETypeParameterValue } from '../verify/verify-mime-type-parameter-value.js';

export function hasMIMETypeParameterInMIMETypeParametersListUnsafe(
  parameters: MIMETypeParametersList,
  key: string,
  value?: string,
): boolean {
  for (let i: number = 0; i < parameters.length; i++) {
    const [_key, _value]: MIMETypeParameterTuple = parameters[i];

    if (_key === key && (value === undefined || _value == value)) {
      return true;
    }
  }

  return false;
}

export function hasMIMETypeParameterInMIMETypeParametersList(
  parameters: MIMETypeParametersList,
  key: string,
  value?: string,
): boolean {
  return hasMIMETypeParameterInMIMETypeParametersListUnsafe(
    parameters,
    normalizeMIMETypeParameterKey(key),
    normalizeMIMETypeParameterValue(value),
  );
}
