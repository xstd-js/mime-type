import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { normalizeMIMETypeParameterKey } from '../verify/verify-mime-type-parameter-key.js';

export function getMIMETypeParameterFromMIMETypeParametersListUnsafe(
  parameters: MIMETypeParametersList,
  key: string,
): string | null {
  for (let i: number = 0; i < parameters.length; i++) {
    if (parameters[i][0] === key) {
      return parameters[i][1];
    }
  }

  return null;
}

export function getMIMETypeParameterFromMIMETypeParametersList(
  parameters: MIMETypeParametersList,
  key: string,
): string | null {
  return getMIMETypeParameterFromMIMETypeParametersListUnsafe(
    parameters,
    normalizeMIMETypeParameterKey(key),
  );
}
