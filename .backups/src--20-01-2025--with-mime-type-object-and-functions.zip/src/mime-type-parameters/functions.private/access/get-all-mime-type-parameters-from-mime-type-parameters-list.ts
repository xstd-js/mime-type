import { type MIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { normalizeMIMETypeParameterKey } from '../verify/verify-mime-type-parameter-key.js';

export function getAllMIMETypeParametersFromMIMETypeParametersListUnsafe(
  parameters: MIMETypeParametersList,
  key: string,
): string[] {
  const values: string[] = [];

  for (let i: number = 0; i < parameters.length; i++) {
    if (parameters[i][0] === key) {
      values.push(parameters[i][1]);
    }
  }

  return values;
}

export function getAllMIMETypeParametersFromMIMETypeParametersList(
  parameters: MIMETypeParametersList,
  key: string,
): string[] {
  return getAllMIMETypeParametersFromMIMETypeParametersListUnsafe(
    parameters,
    normalizeMIMETypeParameterKey(key),
  );
}
