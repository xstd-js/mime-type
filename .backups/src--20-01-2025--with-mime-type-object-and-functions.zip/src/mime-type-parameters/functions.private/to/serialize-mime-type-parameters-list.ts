import { type MIMETypeParameterTuple } from '../../types/mime-type-parameter-tuple.js';
import { type ReadonlyMIMETypeParametersList } from '../../types/mime-type-parameters-list.js';
import { MIME_TYPE_PARAMETER_TOKEN_INNER_PATTERN } from '../constants.js';

/* CONSTANT */

const MIMETypeParameterValueRequiringQuotingRegExp = new RegExp(
  `[^${MIME_TYPE_PARAMETER_TOKEN_INNER_PATTERN}]`,
);

/* TYPE */

export interface SerializeMIMETypeParametersListOptions {
  readonly includeLeadingSeparator?: boolean; // (default: true)
}

/* FUNCTION */

/**
 * Serializes a list of MIME type parameters into a string.
 */
export function serializeMIMETypeParametersList(
  parameters: ReadonlyMIMETypeParametersList,
  { includeLeadingSeparator = false }: SerializeMIMETypeParametersListOptions = {},
): string {
  let output: string = '';

  for (let i: number = 0; i < parameters.length; i++) {
    const [key, value]: MIMETypeParameterTuple = parameters[i];

    if (output !== '' || includeLeadingSeparator) {
      output += '; ';
    }

    const _value: string =
      value === '' || MIMETypeParameterValueRequiringQuotingRegExp.test(value)
        ? `"${value.replaceAll('\\', '\\\\').replaceAll('"', '\\"')}"`
        : value;

    output += `${key}=${_value}`;
  }

  return output;
}
