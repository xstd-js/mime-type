import { serializeMIMETypeParametersList } from '../../mime-type-parameters/functions.private/to/serialize-mime-type-parameters-list.js';
import { type MimeTypeObject } from '../types/mime-type-object.js';

export function serializeMIMETypeObject({ type, subtype, parameters }: MimeTypeObject): string {
  return `${type}/${subtype}${serializeMIMETypeParametersList(parameters, { includeLeadingSeparator: true })}`;
}
