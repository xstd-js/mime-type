import { parseMIMETypeParametersList } from '../../../mime-type-parameters/functions.private/from/parse-mime-type-parameters-list.js';
import { type MimeTypeObject } from '../../types/mime-type-object.js';
import { normalizeMIMETypeSubtype } from '../verify/verify-mime-type-subtype.js';
import { normalizeMIMETypeType } from '../verify/verify-mime-type-type.js';

export function parseMIMEType(input: string): MimeTypeObject {
  let typeAndSubtype: string, parameters: string;

  const indexOfParameters: number = input.indexOf(';');

  if (indexOfParameters === -1) {
    typeAndSubtype = input;
    parameters = '';
  } else {
    typeAndSubtype = input.slice(0, indexOfParameters);
    parameters = input.slice(indexOfParameters);
  }

  const indexOfSubtype: number = typeAndSubtype.indexOf('/');

  if (indexOfSubtype === -1) {
    throw new Error('Invalid MimeType: missing subtype.');
  }

  return {
    type: normalizeMIMETypeType(typeAndSubtype.slice(0, indexOfSubtype)),
    subtype: normalizeMIMETypeSubtype(typeAndSubtype.slice(indexOfSubtype + 1)),
    parameters: parseMIMETypeParametersList(parameters),
  };
}
