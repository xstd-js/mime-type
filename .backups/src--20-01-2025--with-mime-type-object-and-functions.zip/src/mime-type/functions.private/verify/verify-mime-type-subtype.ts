import { MIME_TYPE_TOKEN_PATTERN } from '../constants.js';

const MIMETypeSubtypeRegExp = new RegExp(`^${MIME_TYPE_TOKEN_PATTERN}+$`);

export function verifyMIMETypeSubtype(subtype: string): void {
  if (!MIMETypeSubtypeRegExp.test(subtype)) {
    throw new Error('Invalid subtype');
  }
}

export function normalizeMIMETypeSubtype(subtype: string): string {
  verifyMIMETypeSubtype(subtype);
  return subtype;
}
