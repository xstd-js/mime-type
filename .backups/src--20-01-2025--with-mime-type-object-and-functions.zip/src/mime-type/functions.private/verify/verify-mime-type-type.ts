import { MIME_TYPE_TOKEN_PATTERN } from '../constants.js';

const MIMETypeTypeRegExp = new RegExp(`^${MIME_TYPE_TOKEN_PATTERN}+$`);

export function verifyMIMETypeType(type: string): void {
  if (!MIMETypeTypeRegExp.test(type)) {
    throw new Error('Invalid type');
  }
}

export function normalizeMIMETypeType(type: string): string {
  verifyMIMETypeType(type);
  return type;
}
