export const MIME_TYPE_TOKEN_PATTERN = "[0-9a-zA-Z\\!\\#\\$\\%\\&'\\*\\+\\-\\.\\^_\\`\\|\\~]";
