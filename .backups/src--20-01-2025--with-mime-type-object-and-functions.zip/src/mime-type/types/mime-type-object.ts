import { type ReadonlyMIMETypeParametersList } from '../../mime-type-parameters/types/mime-type-parameters-list.js';

/**
 * An interface describing the parts of a MIME type.
 */
export interface MimeTypeObject {
  readonly type: string;
  readonly subtype: string;
  readonly parameters: ReadonlyMIMETypeParametersList;
}
