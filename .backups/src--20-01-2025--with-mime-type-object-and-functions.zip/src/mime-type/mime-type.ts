import { MIMETypeParameters } from '../mime-type-parameters/mime-type-parameters.js';
import { parseMIMEType } from './functions.private/from/parse-mime-type.js';
import { normalizeMIMETypeSubtype } from './functions.private/verify/verify-mime-type-subtype.js';
import { normalizeMIMETypeType } from './functions.private/verify/verify-mime-type-type.js';
import { MimeTypeObject } from './types/mime-type-object.js';

/* CLASS */

/**
 * Represents a MIME type.
 */
export class MIMEType {
  /**
   * Returns `true` if `input` can be parsed into a valid MIME type.
   */
  static canParse(input: string): boolean {
    return this.parse(input) !== null;
  }

  /**
   * Returns a `MIMEType` if `input` can be parsed a into valid MIME type, else it returns `null`.
   */
  static parse(input: string): MIMEType | null {
    try {
      return new MIMEType(input);
    } catch {
      return null;
    }
  }

  #type: string;
  #subtype: string;
  readonly #parameters: MIMETypeParameters;

  /**
   * Constructs a new MIMEType from an input string.
   *
   * Throws if the `input` is not a valid MIME type.
   *
   * @example
   * ```ts
   * const mimeType = new MIMEType('text/plain; encoding=utf-8');
   * ```
   */
  constructor(input: string) {
    const mimeType: MimeTypeObject = parseMIMEType(input);
    this.#type = mimeType.type;
    this.#subtype = mimeType.subtype;
    this.#parameters = new MIMETypeParameters(mimeType.parameters);
  }

  /**
   * Returns the type of this MIMEType.
   */
  get type(): string {
    return this.#type;
  }

  /**
   * Sets the type of this MIMEType.
   *
   * Throws if the `input` is not a valid type.
   */
  set type(input: string) {
    this.#type = normalizeMIMETypeType(input);
  }

  /**
   * Returns the subtype of this MIMEType.
   */
  get subtype(): string {
    return this.#subtype;
  }

  /**
   * Sets the subtype of this MIMEType.
   *
   * Throws if the `input` is not a valid subtype.
   */
  set subtype(input: string) {
    this.#subtype = normalizeMIMETypeSubtype(input);
  }

  /**
   * Returns the parameters of this MIMEType.
   */
  get parameters(): MIMETypeParameters {
    return this.#parameters;
  }

  /**
   * Returns a MIME type string.
   */
  toString(): string {
    return `${this.#type}/${this.#subtype}${this.#parameters.toString({ includeLeadingSeparator: true })}`;
  }
}
